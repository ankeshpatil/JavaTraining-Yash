package com.yash.oas.exception;


public class UserNotFoundException extends Exception{
	
	public UserNotFoundException(String msg)
	{
		super(msg);
	}

}